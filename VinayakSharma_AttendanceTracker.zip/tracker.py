# =============================================================
# Project: Attendance Tracker - Assignment 01
# Assignment Title: Programming for Problem Solving Using Python - Assignment 01
# Date: 12-11-2025
# Course: Programming for Problem Solving Using Python (ETCCPP171)
# Program: MCA (AI & ML) | Semester: I | Session: 2025-26
# Faculty: Ms. Neha Kaushik
# Student Name: Vinayak Sharma
# =============================================================
# Description:
# A Python-based command-line attendance tracker that allows
# users to record student names, validate entries, display
# formatted attendance summaries, and optionally save reports.
# =============================================================

from datetime import datetime

# ---------- WELCOME PAGE ----------
print("="*65)
print("K.R. Mangalam University - School of Engineering & Technology")
print("-"*65)
print("Course: Programming for Problem Solving Using Python (ETCCPP171)")
print("Student: Vinayak Sharma")
print("Program: MCA (AI & ML) | Semester: I | Session: 2025-26")
print("="*65)
print("Welcome to the Python Attendance Tracker!")
print("Easily record, validate, and save student attendance data.")
print("="*65)
print()

# ---------- TASK 2: INPUT & DATA COLLECTION ----------
attendance = {}

while True:
    try:
        num_students = int(input("Enter number of students to record: "))
        if num_students <= 0:
            print("Please enter a positive number.\n")
            continue
        break
    except ValueError:
        print("Invalid input! Please enter a valid number.\n")

# ---------- TASK 3: DATA VALIDATION & COLLECTION ----------
for i in range(1, num_students + 1):
    print(f"\nEntry {i}:")
    
    while True:
        name = input("Enter student name: ").strip().title()
        if not name:
            print("Name cannot be empty. Try again.")
            continue
        if name in attendance:
            print("Duplicate entry! This name already exists.")
            continue
        break

    while True:
        time_in = input("Enter check-in time (e.g., 09:15 AM): ").strip()
        if not time_in:
            print("Time cannot be empty. Try again.")
            continue
        break

    attendance[name] = time_in

# ---------- TASK 4: ATTENDANCE SUMMARY ----------
print("\n\n" + "="*40)
print("Attendance Summary")
print("="*40)
print(f"{'Student Name':<25} {'Check-in Time':<15}")
print("-"*40)

for student, time_in in attendance.items():
    print(f"{student:<25} {time_in:<15}")

print("-"*40)
print(f"Total Students Present: {len(attendance)}")
print("="*40)

# ---------- TASK 5: ABSENTEE VALIDATION (Optional) ----------
total_strength = input("\nEnter total number of students in class (or press Enter to skip): ").strip()

absentees = None
if total_strength.isdigit():
    total_strength = int(total_strength)
    absentees = total_strength - len(attendance)
    if absentees < 0:
        absentees = 0
    print(f"Total Absent: {absentees}")
else:
    print("Skipping absentee calculation...")

# ---------- TASK 6: SAVE REPORT ----------
save_choice = input("\nDo you want to save the attendance report? (yes/no): ").strip().lower()

if save_choice in ['yes', 'y']:
    filename = "attendance_log.txt"
    try:
        with open(filename, "w", encoding="utf-8") as file:
            file.write("K.R. Mangalam University - Attendance Report\n")
            file.write(f"Generated on: {datetime.now().strftime('%d-%m-%Y %I:%M %p')}\n\n")
            file.write(f"{'Student Name':<25} {'Check-in Time':<15}\n")
            file.write("-"*40 + "\n")
            for student, time_in in attendance.items():
                file.write(f"{student:<25} {time_in:<15}\n")
            file.write("-"*40 + "\n")
            file.write(f"Total Present: {len(attendance)}\n")
            if isinstance(absentees, int):
                file.write(f"Total Absent: {absentees}\n")
        print(f"\n Attendance saved successfully to '{filename}'.")
    except Exception as e:
        print("Failed to save the file:", e)
else:
    print("\nReport not saved. Exiting program...")

print("\nThank you for using the Attendance Tracker, Vinayak! ")
print("="*65)
